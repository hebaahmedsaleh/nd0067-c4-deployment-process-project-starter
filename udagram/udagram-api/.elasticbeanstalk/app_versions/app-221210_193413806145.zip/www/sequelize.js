"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sequelize = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const config_1 = require("./config/config");
const { username, password, rds_db_url, posgres_port, database } = config_1.config;
const stringUrl = `postgres://${username}:${password}@${rds_db_url}:${posgres_port}/postgres`;
var options = {
    host: rds_db_url,
    user: username,
    password: password,
    port: posgres_port
};
exports.sequelize = new sequelize_typescript_1.Sequelize(stringUrl);
//# sourceMappingURL=sequelize.js.map